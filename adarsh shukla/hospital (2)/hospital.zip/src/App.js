import "./App.css";
import GeneralExamination from "./components/GeneralExamination";
import HusbandDetail from "./components/HusbandDetail";
import Investigations from "./components/Investigations";
import OtherDetails from "./components/OtherDetails";
import PatientHistory from "./components/PatientHistory";

function App() {
  return (
    <>
      <PatientHistory />
      <HusbandDetail />
      <GeneralExamination />
      <Investigations/>
      <OtherDetails />

    </>
  );
}

export default App;
