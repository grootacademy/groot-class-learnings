import logo from './logo.svg';
import './App.css';
import AddPaitient from './components/AddPaitient';

function App() {
  return (
    <>
      <AddPaitient/>
      
    </>
  );
}

export default App;
