jsx
Components
props
state
lifecycle methods
hooks
routing