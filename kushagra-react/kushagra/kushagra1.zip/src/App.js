import './App.css';
import Form from './components/Form';
import Navbar from './components/Navbar';
import Cards2 from './components/Cards2';
import State from './components/State';

function App() {
  return (
    <>
      {/* <Navbar />
      <Cards2 />
      <Form /> */}
      <State />
    </>
  );
}

export default App;
